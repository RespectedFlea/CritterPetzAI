namespace CritterPetz
{
    public enum EggType
    {
        None,
        Cat,
        Dog
        // Add more types as needed
    }
}
