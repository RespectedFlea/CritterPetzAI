Thank you for downloading House Interior 32 x 32 Tileset LITE.

Please find the sliced image in this folder.
See the demo for how to use the tiles, or as a jumping off point.

If you are interested in more tiles, consider purchasing the full version.

By downloading this project from Unity, you are free to use it in all your Unity projects,
commercial or otherwise.